# Summarizer prompt
