print("weekly review placeholder")
