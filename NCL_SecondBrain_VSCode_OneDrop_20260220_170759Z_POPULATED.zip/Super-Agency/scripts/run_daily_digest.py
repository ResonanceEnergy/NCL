print("daily digest placeholder")
